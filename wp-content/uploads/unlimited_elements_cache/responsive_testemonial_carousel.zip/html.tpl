{% if rtl == "false" %}<div class="uc_quote_slider" style="direction:ltr" >{% endif %}
{% if rtl == "true" %}<div class="uc_quote_slider" style="direction:rtl" >{% endif %}
  
  <!-- carousel type owl -->
  {% if carousel_type == "owl" %}
	<div class="uc_carousel owl-carousel owl-theme uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
      {{put_items()}}
    </div>		
  {% endif %}
  <!-- end carousel type owl -->

  <!-- carousel type marquee -->
  {% if carousel_type == "marquee" %}
    <div class="uc_logo_marquee {{uc_filtering_addclass}} uc_marquee_{{direction_marquee}}" id="{{uc_id}}" style="direction:ltr;" {{uc_filtering_attributes|raw}}>
      <div class="uc_marquee uc-items-wrapper" data-height="{{box_height}}" data-speed="{{transition_speed_marquee}}" data-mobile-items="{{number_of_items_marquee_mobile}}" data-tablet-items="{{number_of_items_marquee_tablet}}" data-desktop-items="{{number_of_items_marquee}}" data-margin="{{margin_between_items_marquee}}" data-paused="{{autoplay_hover_pause_marquee}}" data-direction="{{direction_marquee}}">
        {{put_items()}}
      </div>	
    </div>
  {% endif %}
  <!-- end carousel type marquee -->

  <!-- carousel type coverflow -->
  {% if carousel_type == "coverflow" %}
    <div class="ue-coverflow {{remote_parent.class|raw}} {{uc_filtering_addclass}} {% if remove_item_reflection_coverflow == "true" %}ue-coverflow-no-reflection{% endif %} {% if content_layout_coverflow == "overlay" %}ue-coverflow-overlay{% endif %}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
      <ul class="flip-items uc-items-wrapper">
        {{put_items()}}
      </ul>
	</div>
  {% endif %}
  <!-- end carousel type coverflow -->

  <!-- carousel type swipe -->
  {% if carousel_type == "swipe" %}
	<div id="{{uc_id}}" class="swipe_css_carousel {% if snap_to_carousel_item_swipe == "true" %}swipe_css_carousel-snap{% endif %} {{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}} data-show-title="{{show_title}}" data-show-text="{{show_text}}" data-justified-widths="{{justified_widths}}">
      <div style="height:10px;flex-shrink: 0;" class="startGap"></div>
      <div class="uc-items-wrapper">{{put_items()}}</div>
      <div style="height:10px;flex-shrink: 0;" class="endGap"></div>
    </div>
  {% endif %}
  <!-- end carousel type swipe -->

  <!-- carousel type grid -->
  {% if carousel_type == "grid" %}
	<div id="{{uc_id}}" class="team_member_grid uc-items-wrapper {{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}}>
      {{put_items()}}
	</div>
  {% endif %}
  <!-- end carousel type grid -->

</div>{# end uc_quote_slider #}{##}