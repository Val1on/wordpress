{# twig vars #}{##}
{% set fullStarElem %}<div class="ue_rate">{{full_html|raw}}</div>{% endset %}
{% set halfStarElem %}<div class="ue_rate">{{half_html|raw}}</div>{% endset %}
{% set emptyStarElem %}<div class="ue_rate">{{empty_html|raw}}</div>{% endset %}
{# end twig vars #}{##}

{% if carousel_type == "coverflow" %}
  {% if navigation_type_coverflow == "title" %}
    <li class="ue-coverflow-item uc_quote_item ue-item uc_logo_marquee_holder {{item.item_repeater_class}}" data-flip-title="{{item.title}}">
  {% endif %}

  {% if navigation_type_coverflow == "index" %}
    <li class="ue-coverflow-item uc_quote_item ue-item uc_logo_marquee_holder {{item.item_repeater_class}}" data-flip-title="{{item.item_index}}">
  {% endif %}      
{% else %}
	<div class="uc_quote_item ue-item {% if carousel_type == "marquee" %}uc_logo_marquee_holder{% endif %} {% if carousel_type == "swipe" %}galleryItem{% endif %} {% if carousel_type == "grid" %}ue_grid_item{% endif %} {% if equalize_to_maximum_height == "true" %}ue-item-equalize-height{% endif %} {{item.item_repeater_class}}">
{% endif %}
    <div class="uc_quote_info {% if carousel_type == "coverflow" %}ue-flip-item-content{% endif %}">
                
	  <div class="uc_author">
        {% if show_image == "true" %}
          <div class="ue-image">
	        <img class="uc_author_avatar" src="{{item.image}}" height="48" width="48" alt="" />
          </div>
          <div class="ue-image-spacing"></div>
        {% endif %}
                  
		<div class="uc_author_info">
		  {% if show_title == "true" %}{% if item.title_link is not empty %}<a href="{{item.title_link}}" {{item.title_link_html_attributes|raw}}>{% endif %}<div class="ue_title">{{item.title|raw}}</div>{% if item.title_link is not empty %}</a>{% endif %}{% endif %}
		  {% if show_subtitle == "true" %}<div class="ue_subtitle">{{item.subtitle|raw}}</div>{% endif %}
		</div>
        
	  </div>{# end uc_author #}{##}
      <!-- end of credentials -->
              
      {% if show_text == "true" %}
        <div class="ue-text">
          <p>{{item.text|raw}}</p>      	  
        </div>
        {% if show_unfold_content_button == "true" %}
          <div class="ue-text-unfold-btn" role="button">
            <span class="ue-text-folded">{{unfold_btn_text|ucsafe|raw}}</span>
        	<span class="ue-text-unfolded">{{fold_btn_text|ucsafe|raw}}</span>
          </div>
        {% endif %}
      {% endif %}
              
      {% if show_rating == "true" %}
        <div class="uc_stars">
          {% if item.rating == "5" %}{% for i in 1..5 %}{{fullStarElem}}{% endfor %}{% endif %}
          {% if item.rating == "4.5" %}{% for i in 1..4 %}{{fullStarElem}}{% endfor %}{{halfStarElem}}{% endif %}
          {% if item.rating == "4" %}{% for i in 1..4 %}{{fullStarElem}}{% endfor %}{{emptyStarElem}}{% endif %}
          {% if item.rating == "3.5" %}{% for i in 1..3 %}{{fullStarElem}}{% endfor %}{{halfStarElem}}{{emptyStarElem}}{% endif %}
          {% if item.rating == "3" %}{% for i in 1..3 %}{{fullStarElem}}{% endfor %}{% for i in 1..2 %}{{emptyStarElem}}{% endfor %}{% endif %}
          {% if item.rating == "2.5" %}{% for i in 1..2 %}{{fullStarElem}}{% endfor %}{{halfStarElem}}{% for i in 1..2 %}{{emptyStarElem}}{% endfor %}{% endif %}
          {% if item.rating == "2" %}{% for i in 1..2 %}{{fullStarElem}}{% endfor %}{% for i in 1..3 %}{{emptyStarElem}}{% endfor %}{% endif %}
          {% if item.rating == "1.5" %}{{fullStarElem}}{{halfStarElem}}{% for i in 1..3 %}{{emptyStarElem}}{% endfor %}{% endif %}
          {% if item.rating == "1" %}{{fullStarElem}}{% for i in 1..4 %}{{emptyStarElem}}{% endfor %}{% endif %}
        </div>{# end uc_stars #}{##}
      {% endif %}{# end show_rating == "true" #}{##}
	        
      {% if show_icon == "true" %}
        <div><div class="ue-icon">{{icon_html|raw}}</div></div>
      {% endif %}
              
	</div>{# end uc_quote_info #}{##}
{% if carousel_type == "coverflow" %}
  </li>
{% else %}
   </div>
{% endif %}
<!-- end of block item -->