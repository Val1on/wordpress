<div class="blox-border-bar-counter" id="{{uc_id}}">
	<div class="blox-bar-row progress-new progress-all" role="progressbar" data-goal="{{amount}}" data-speed="{{speed}}">
        <div class="blox-bar-heading">
            <div class="blox-bar-title">{{title|raw}}</div>
            <div class="blox-border-bar-percentage progressnew__label" style="color:{{amount_color}};"></div>
        </div>
        <div class="blox-border-bar" style="background-color:{{border_color}};">
            <div class="blox-border-progress-bar progressnew__bar" ></div>
        </div>
    </div>
</div>