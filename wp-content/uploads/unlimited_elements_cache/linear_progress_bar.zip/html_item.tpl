<div class="blox-bar-row progress-new" role="progressbar" data-goal="{{item.amount}}" data-speed="{{speed}}">
    <div class="blox-bar-heading">
        <div class="blox-bar-title">{{item.title|raw}}</div>
        <div class="blox-border-bar-percentage progressnew__label"></div>
    </div>
    <div class="blox-border-bar" style="background-color:{{border_color}};">
        <div class="blox-border-progress-bar progressnew__bar" style="background-color:{{item.color}};"></div>
    </div>
</div>